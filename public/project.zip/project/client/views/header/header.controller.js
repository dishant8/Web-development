﻿(function () {
    'use strict';

    angular
    .module("FoodOrderApp")
    .controller("HeaderController", HeaderController)

    function HeaderController($scope, $location, $rootScope, AuthService, UserService) {
        //        $scope.user = "notPresent";
        $scope.$location = $location;
        console.log("AYA")

        var init = function () {
            console.log("ARE U GETTING CALLED")
            if (AuthService.isAuth()) {
                var userId = AuthService.getUser();
                if (userId) {
                    UserService.findUserById(userId)
                    .then(function (user) {
                        $rootScope.user = user;
                        $rootScope.$broadcast('auth', user);
                        console.log("HEADER REACHED")
                    });
                };
            };
        };
        init();

        $scope.logout = function () {
            $rootScope.user = null;
            AuthService.setUser(null);
            $location.path("/home");
        };

    }


})()


