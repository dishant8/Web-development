﻿(function () {
    angular
        .module("FoodOrderApp", ["ngRoute", 'ngMap', "ngCookies"])

})();