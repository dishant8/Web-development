﻿(function () {
    angular
        .module("FoodOrderApp")
        
})